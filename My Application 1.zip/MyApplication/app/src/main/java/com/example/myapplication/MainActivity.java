package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import java.time.LocalDate;
import java.time.Year;
import java.time.format.DateTimeFormatter;
import java.time.temporal.WeekFields;
import java.util.Locale;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText day,year;
        Button check;


        TextView date,week,leap;


        day=findViewById(R.id.day);
        year=findViewById(R.id.year);

        check=findViewById(R.id.checkB);

        date=findViewById(R.id.date);
        week=findViewById(R.id.week);
        leap=findViewById(R.id.leap);


        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int days=Integer.parseInt(day.getText().toString());
                int years=Integer.parseInt(year.getText().toString());

                LocalDate date1= LocalDate.ofYearDay(days,years);
                date.setText("Date: "+date1.toString());

                WeekFields week1=WeekFields.of(Locale.getDefault());
                date1.get(week1.weekOfWeekBasedYear());
                week.setText("Week: "+date1.get(week1.weekOfWeekBasedYear()));

                boolean leapy= Year.isLeap(years);

                if (leapy){

                    leap.setText("LEAP?: YES");

                }
                else {
                    leap.setText("LEAP?: NO");
                }



            }
        });
    }
}